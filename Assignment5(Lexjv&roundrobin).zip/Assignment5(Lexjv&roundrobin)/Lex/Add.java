import java.util.*;

public class Add{
public static void main(String args[])
{
 int a=0, b=0,c=0.0;
 a=7;
 b=9;     //variable intilization
 c=a+b;	  /*Addition of two variable*/
 System.out.println("The 'addtion' of "+a+" & "+b+" is "+c);
 if (a == 12) {
 
 }
}
}
